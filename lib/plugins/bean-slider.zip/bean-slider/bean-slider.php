<?php
/**
 * Plugin Name: Bean Krative Home Slider
 * Plugin URI: http://themebeans.com
 * Description: Enables a slider post type for use in the Krative WordPress Theme by ThemeBeans. 
 * Version: 1.1
 * Author: ThemeBeans
 * Author URI: http://themebeans.com
 *  
 *   
 * @package Bean Plugins
 * @subpackage BeanKrativeHomeSlider
 * @author ThemeBeans
 * @since BeanKrativeHomeSlider 1.0
 */

if ( ! class_exists( 'Bean_Slider_Post_Type' ) ) :
class Bean_Slider_Post_Type 
{
	function __construct()
	{
		// PLUGIN ACTIVATION
		register_activation_hook( __FILE__, array( &$this, 'plugin_activation' ) );
		
		// TRANSLATION
		load_plugin_textdomain( 'bean', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		
		add_action( 'init', array( &$this, 'slider_init' ) );
		add_action( 'restrict_manage_posts', array( &$this, 'add_taxonomy_filters' ) );
		add_action( 'right_now_content_table_end', array( &$this, 'add_slider_counts' ) );
		add_action( 'admin_menu', array( &$this, 'bean_create_slider_sort_page') );
		add_action( 'wp_ajax_slider_sort', array( &$this, 'bean_save_slider_sorted_order' ) );	
		add_action( 'admin_head', array( &$this, 'custom_post_type_icon' ) );
	}
	
	


	/*===================================================================*/
	/* FLUSH REWRITE RULE
	/*===================================================================*/ 
	function plugin_activation() 
	{
		$this->slider_init();
		flush_rewrite_rules();
	}
	
	
	
	
	/*===================================================================*/
	/* REGISTER POST TYPE
	/*===================================================================*/ 
	function slider_init() 
	{
		$labels = array(
			'name' 				 => __( 'Slides', 'bean' ),
			'singular_name' 	 => __( 'Home Slide', 'bean' ),
			'add_new' 			 => __( 'Add New Slide', 'bean' ),
			'add_new_item'		 => __( 'Add New Slider', 'bean' ),
			'edit_item' 		 => __( 'Edit Slider', 'bean' ),
			'new_item' 			 => __( 'Add New', 'bean' ),
			'view_item' 		 => __( '', 'bean' ),
			'search_items' 		 => __( '', 'bean' ),
			'not_found' 		 => __( 'No slider items found', 'bean' ),
			'not_found_in_trash' => __( 'No slider items found in trash', 'bean' )
		);
		
		$args = array(
	    	'labels' 			=> $labels,
	    	'public' 			=> true,
			'supports' 			=> array( 'title', 'editor'),
			'capability_type' 	=> 'post',
			'rewrite' 			=> array("slug" => "slider"),
			'menu_position' 	=> 20,
			'has_archive' 		=> true,
			'menu_icon'		    => '',
		);
		
		$args = apply_filters('bean_args', $args);

		register_post_type( 'slider', $args );		
	}




	/*===================================================================*/
	/* ADD TAXONOMY FILTERS TO THE ADMIN PAGE
	/*===================================================================*/ 
	function add_taxonomy_filters() 
	{
		global $typenow;
		
		// USE TAXONOMY NAME OR SLUG
		$taxonomies = array( 'slider_category', 'slider_tag' );
	}
	
	


	/*===================================================================*/
	/* ADD COUNT TO "RIGHT NOW" DASHBOARD WIDGET
	/*===================================================================*/ 
	function add_slider_counts() 
	{
        if ( ! post_type_exists( 'slider' ) ) 
        {
             return;
        }

        $num_posts = wp_count_posts( 'slider' );
        $num = number_format_i18n( $num_posts->publish );
        $text = _n( 'Slider Item', 'Slider Items', intval($num_posts->publish) );
        if ( current_user_can( 'edit_posts' ) ) {
            $num = "<a href='edit.php?post_type=slider'>$num</a>";
            $text = "<a href='edit.php?post_type=slider'>$text</a>";
        }
        echo '<td class="first b b-slider">' . $num . '</td>';
        echo '<td class="t slider">' . $text . '</td>';
        echo '</tr>';

        if ($num_posts->pending > 0) 
        {
            $num = number_format_i18n( $num_posts->pending );
            $text = _n( 'Slider Item Pending', 'Slider Items Pending', intval($num_posts->pending) );
            if ( current_user_can( 'edit_posts' ) ) {
                $num = "<a href='edit.php?post_status=pending&post_type=slider'>$num</a>";
                $text = "<a href='edit.php?post_status=pending&post_type=slider'>$text</a>";
            }
            echo '<td class="first b b-slider">' . $num . '</td>';
            echo '<td class="t slider">' . $text . '</td>';

            echo '</tr>';
        }
	}




	/*===================================================================*/
	/* SORTING
	/*===================================================================*/ 
	function bean_create_slider_sort_page() 
	{
	    $bean_sort_page = add_submenu_page('edit.php?post_type=slider', __('Sort Sliders', 'bean'), __('Sort', 'bean'), 'edit_posts', basename(__FILE__), array($this, 'bean_slider_sort'));
	    
	    add_action('admin_print_styles-' . $bean_sort_page, array($this, 'bean_print_sort_styles')) ;
	    add_action('admin_print_scripts-' . $bean_sort_page , array($this,'bean_print_sort_scripts'));
	}
	
	//OUTPUT FOR SORTING PAGE
	function bean_slider_sort() 
	{
	    $sliders = new WP_Query('post_type=slider&posts_per_page=-1&orderby=menu_order&order=ASC'); ?>
	   
	    <div class="wrap">
	    
	        <div id="icon-edit" class="icon32"></div>
	        
	        <h2><?php _e('Sort Krative Home Template Slides', 'bean'); ?></h2>
	        
	        <p><?php _e('Click, drag, re-order & repeat as necessary. The item at the top of the list will display first in the home slider.', 'bean'); ?></p>
	
		        <ul id="slider_list">
		        
		            <?php while( $sliders->have_posts() ) : $sliders->the_post();
		        
		                if( get_post_status() == 'publish' ) { ?>
		        
		                    <li id="<?php the_id(); ?>" class="menu-item">
		        
		                        <dl class="menu-item-bar">
		        
		                            <dt class="menu-item-handle">
		        
		                                <span class="menu-item-title"><?php the_title(); ?></span>
		        
		                            </dt><!-- END .menu-item-handle -->
		        
		                        </dl><!-- END .menu-item-bar --> 
		        
		                        <ul class="menu-item-transport"></ul>
		        
		                    </li><!-- END .menu-item -->
	
		            <?php } endwhile; wp_reset_postdata(); ?>
		        
		        </ul><!-- END #slider_list -->
	    
	    	</div><!-- END .wrap -->
	
	<?php }
	
	//ORDER
	function bean_save_slider_sorted_order() 
	{
	    global $wpdb;
	    
	    $order = explode(',', $_POST['order']);
	    $counter = 0;
	    
	    foreach($order as $slider_id) {
	        $wpdb->update($wpdb->posts, array('menu_order' => $counter), array('ID' => $slider_id));
	        $counter++;
	    }
	    die(1);
	}
	
	//SCRIPTS
	function bean_print_sort_scripts() 
	{
	    wp_enqueue_script('jquery-ui-sortable');
	    wp_enqueue_script( 'bean_slider_sort', plugins_url( '/js/bean_sort.js', __FILE__ ), array('jquery') );
	
	}
	
	//SORTER STYLES
	function bean_print_sort_styles() 
	{
	    wp_enqueue_style ('nav-menu');
	}	
	
	


	/*===================================================================*/
	/* CUSTOM ICON FOR POST TYPE
	/*===================================================================*/ 
	function custom_post_type_icon() 
	{ ?>
		<style type="text/css" media="screen">
			#adminmenu #menu-posts-slider div.wp-menu-image:before { content: '\f181'; }
		</style>
	<?php 
	}
	
} //END class Bean_Slider_Post_Type 

new Bean_Slider_Post_Type;

endif;